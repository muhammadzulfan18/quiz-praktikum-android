package id.ac.amikom.pertemuan6

interface LuasView {
    fun HasilLuasPersegiPanjang (Luas: Float)
}
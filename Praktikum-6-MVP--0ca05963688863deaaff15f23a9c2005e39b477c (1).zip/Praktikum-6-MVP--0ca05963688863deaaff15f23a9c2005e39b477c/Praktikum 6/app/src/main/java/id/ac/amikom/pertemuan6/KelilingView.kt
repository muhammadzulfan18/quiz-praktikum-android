package id.ac.amikom.pertemuan6

interface KelilingView {
    fun HasilKelilingPersegiPanjang (Keliling: Float)
}